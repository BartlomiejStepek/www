$(document).ready(function() {
  $('#info1').click(function() {
    hideShow('#info');
    $('#info1').attr('disabled', true);
    $('#popular1').attr('disabled', false);
    $('#beauty1').attr('disabled', false);
    $('#interest1').attr('disabled', false);
    $('#gallery1').attr('disabled', false);
  });
  $('#popular1').click(function() {
    hideShow('#popular');
    $('#info1').attr('disabled', false);
    $('#popular1').attr('disabled', true);
    $('#beauty1').attr('disabled', false);
    $('#interest1').attr('disabled', false);
    $('#gallery1').attr('disabled', false);
  });
  $('#beauty1').click(function() {
    hideShow('#beauty');
    $('#info1').attr('disabled', false);
    $('#popular1').attr('disabled', false);
    $('#beauty1').attr('disabled', true);
    $('#interest1').attr('disabled', false);
    $('#gallery1').attr('disabled', false);
  });
  $('#gallery1').click(function() {
    hideShow('#gallery');
    $('#info1').attr('disabled', false);
    $('#popular1').attr('disabled', false);
    $('#beauty1').attr('disabled', false);
    $('#interest1').attr('disabled', false);
    $('#gallery1').attr('disabled', true);
  });
  $('#interest1').click(function() {
    hideShow('#interest');
    $('#info1').attr('disabled', false);
    $('#popular1').attr('disabled', false);
    $('#beauty1').attr('disabled', false);
    $('#interest1').attr('disabled', true);
    $('#gallery1').attr('disabled', false);
  });
  if (window.location.hash === '') {
    hideShow('#info');
    $('#info1').attr('disabled', true);
  }
  window.location.hash = '';
  const container = document.querySelector('.container');

  const URL = 'https://dog.ceo/api/breeds/image/random'

  function loadImages(numImages = 5) {
    let i = 0;
    while (i < numImages) {
      fetch('https://dog.ceo/api/breeds/image/random')
        .then(response => response.json())
        .then(data => {
          const img = document.createElement('img');
          img.src = `${data.message}`
          container.appendChild(img)
        })
      i++;
    }
  }

  loadImages();

  window.addEventListener('scroll', () => {
    console.log("scrolled", window.scrollY) //scrolled from top
    console.log(window.innerHeight) //visible part of screen
    if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight) {
      loadImages();
    }
  })
});

function hideShow(el) {
  $('.box').hide();
  $(el).show();
  $('.tab').removeClass('active');
  $('a[href="' + el + '"]').addClass('active');
}