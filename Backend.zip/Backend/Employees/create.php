<?php

include("../header.php");

$nameError = false;
$nameErrors = array();

$surnameError = false;
$surnameErrors = array();

$positionError = false;
$positionErrors = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $position = $_POST['position'];

    if(empty($name)){
        array_push($nameErrors, "Pole nie może być puste");
        $nameError = true;
    }else if(empty($surname)){
        array_push($surnameErrors, "Pole nie może być puste");
        $surnameError = true;
    }else if(empty($position)){
        array_push($positionErrors, "Pole musi być dodatnią liczbą");
        $positionError = true;
    }

    if (!$nameError && !$surnameError && !$positionError) {

        $query = "INSERT INTO employee (name, surname, position) VALUES('$name', '$surname', '$position')";
        mysqli_query($db, $query);
        header('location: /RegisterLogin/Employees/index.php');

    }

}

?>

<div class="container ">

    <h1 class="text-center">Add new employee</h1>
    <hr>

    <div class="row  m-5 justify-content-center">
        <form method="post" class="col-md-3">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name"
                       value="<?php if (isset($name)) echo "$name"; ?>" placeholder="Enter surname">
                <?php
                if ($nameError) {
                    foreach ($nameErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="surname">Surname</label>
                <input type="text" class="form-control" id="surname" name="surname"
                       value="<?php if (isset($surname)) echo "$surname"; ?>" placeholder="Enter surname">
                <?php
                if ($surnameError) {
                    foreach ($surnameErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="position">Position</label>
                <input type="text" class="form-control" id="position" name="position"
                       value="<?php if (isset($position)) echo "$position"; ?>"
                       placeholder="Enter employee position">

                <?php
                if ($positionError) {
                    foreach ($positionErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>

            </div>

            <button type="submit" class="col btn btn-primary">Add employee</button>

        </form>
    </div>
</div>
