<?php

require_once "../config.php";

if($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id'];
    $sql = "Delete from employee where id = ".$id;

    if(mysqli_query($db, $sql)){
        header('location: /RegisterLogin/Employees/index.php');
    }else{
        echo "Błąd: " . mysqli_error($db);
    }
}