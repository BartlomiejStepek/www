<?php

include("../header.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $position = $_POST['position'];


    $sql = "Update employee set name = '" . $name . "', surname = '" . $surname . "', position = '" . $position . "' where id = " . $id;

    mysqli_query($db, $sql);
    header('location: /RegisterLogin/Employees/index.php');

}

if ($_SERVER["REQUEST_METHOD"] == "GET") {

    $id = $_GET['id'];
    $sql = "Select * from employee where id = " . $id;

    $result = mysqli_query($db, $sql);

    $name = $surname = $position = "";


    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $description = $row['surname'];
    $price = $row['position'];

    echo "
        
        <div class='container'>

    <h1 class='text-center'>Employee</h1>
    <hr>

    <div class='row  m-5 justify-content-center'>
        
        <form method='post'>
    <div class='form-group'>
        <label for='name'>Name</label>
        <input class='form-control' type='text' placeholder='Name' name='name' value='" . $name . "'>
    </div>
    <div class='form-group'>
        <label for='surname'>Surname</label>
        <input class='form-control' type='text' placeholder='Surname' name='surname' value='" . $description . "'>
    </div>
    <div class='form-group'>
        <label for='position'>Position</label>
        <input class='form-control' type='text' placeholder='Position' name='position' value='" . $price . "'>
    </div>
    <div class='row d-flex justify-content-center'>
        <form method='post' class='mx-2'>
            <button type='submit' value='" . $id . "' name='id' class='btn btn-success'>Save</button>
        </form>
        <form action='index.php' method='get' class='mx-2'>
            <button type='submit' class='btn btn-danger'>Cancel</button>
        </form>
    </div>
</div>
</div>
        ";

}

?>
