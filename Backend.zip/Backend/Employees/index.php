<?php


include("../header.php");

$loggedUser = isset($_SESSION["username"]);

?>

<div class="container ">

    <h1 class="text-center">Employees</h1>
    <hr>

    <div class="row  m-5 justify-content-center">

        <table class='table'>
            <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Surname</th>
                <th>Position</th>
                <?php
                if ($loggedUser) {
                    echo "<th> Actions</th>";
                }
                ?>
            </tr>
            </thead>
            <tbody>
            <?php

            $result = mysqli_query($db, "Select id, name, surname, position from employee");

            while ($row = mysqli_fetch_assoc($result)) {
                echo "
                <tr>
                    <td>" . $row['id'] . "</td>
                    <td>" . $row['name'] . "</td>
                    <td>" . $row['surname'] . "</td>
                    <td>" . $row['position'] . "</td>";
                if ($loggedUser) {
                    echo "
                    <td>
                    <div class='row'>
                    <form method='get' action='edit.php' class='mx-2'>
                    <button type='submit' value='" . $row['id'] . "' name='id' class='btn btn-primary'>Edit</button>
                    </form>
                    <form method='post' action='delete.php'>
                    <button type='submit' value='" . $row['id'] . "' name='id' class='btn btn-danger'>Delete</button>
                    </form>
                    </div>
                    </td>";
                }
                echo "</tr>";
            }

            ?>
            </tbody>
        </table>

        <form method="get" action="create.php">
            <button class="btn btn-success">Add employee</button>
        </form>
    </div>
</div>