<?php
session_start();
ob_start();

//Połączenie z bazą danych
$db = mysqli_connect('localhost', 'd44480_root', 'Administrator12a@', 'd44480_mydatabase');

//Sprawdzamy czy nie ma błedów
if (mysqli_connect_errno()) {
    exit('Błąd połączenia: ' . mysqli_connect_error());
}