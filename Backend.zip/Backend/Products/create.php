<?php

include("../header.php");

$nameError = false;
$nameErrors = array();

$descriptionError = false;
$descriptionErrors = array();

$priceError = false;
$priceErrors = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if(empty($name)){
        array_push($nameErrors, "Pole nie może być puste");
        $nameError = true;
    }else if(empty($description)){
        array_push($descriptionErrors, "Pole nie może być puste");
        $descriptionError = true;
    }else if(empty($price) || $price <= 0){
        array_push($priceErrors, "Pole musi być dodatnią liczbą");
        $priceError = true;
    }

    if (!$nameError && !$descriptionError && !$priceError) {
        $product_check_query = "SELECT * FROM product WHERE name='$name' LIMIT 1";
        $result = mysqli_query($db, $product_check_query);
        $product = mysqli_fetch_assoc($result);

        if ($product) {
            if ($product['name'] === $name) {
                array_push($errors, "Produkt o podanej nazwie już istnieje");
            }
        }else{
            $query = "INSERT INTO product (name, description, price) VALUES('$name', '$description', '$price')";
            mysqli_query($db, $query);
            header('location: /RegisterLogin/Products/index.php');
        }
    }

}

?>

<div class="container ">

    <h1 class="text-center">Add new product</h1>
    <hr>

    <div class="row  m-5 justify-content-center">
        <form method="post" class="col-md-3">

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name"
                       value="<?php if (isset($name)) echo "$name"; ?>" placeholder="Enter product name">
                <?php
                if ($nameError) {
                    foreach ($nameErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <input type="text" class="form-control" id="description" name="description"
                       value="<?php if (isset($description)) echo "$description"; ?>" placeholder="Enter product desription">
                <?php
                if ($descriptionError) {
                    foreach ($descriptionErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" id="price" name="price"
                       value="<?php if (isset($price)) echo "$price"; ?>"
                       placeholder="Enter product price">

                <?php
                if ($priceError) {
                    foreach ($priceErrors as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>

            </div>

            <button type="submit" class="col btn btn-primary">Add product</button>

        </form>
    </div>
</div>
