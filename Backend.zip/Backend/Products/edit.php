<?php

include("../header.php");

//Jeżeli otrzymaliśmy żądanie POST to edytujemy dane
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];


    $sql = "Update product set name = '" . $name . "', description = '" . $description . "', price = '" . $price . "' where idproduct = " . $id;

    mysqli_query($db, $sql);
    header('location: /RegisterLogin/Products/index.php');

}

//Jeżeli otrzymaliśmy żądanie GET to wypisujemy dane
if ($_SERVER["REQUEST_METHOD"] == "GET") {

    $id = $_GET['id'];
    $sql = "Select * from product where idproduct = " . $id;

    $result = mysqli_query($db, $sql);

    $name = $description = "";
    $price = 0;


    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $description = $row['description'];
    $price = $row['price'];

    echo "
        
        <div class='container'>

    <h1 class='text-center'>Product</h1>
    <hr>

    <div class='row  m-5 justify-content-center'>
        
        <form method='post'>
    <div class='form-group'>
        <label for='name'>Name</label>
        <input class='form-control' type='text' placeholder='Name' name='name' value='" . $name . "'>
    </div>
    <div class='form-group'>
        <label for='description'>Description</label>
        <input class='form-control' type='text' placeholder='Description' name='description' value='" . $description . "'>
    </div>
    <div class='form-group'>
        <label for='price'>Price</label>
        <input class='form-control' type='number' step='0.1' placeholder='Price' name='price' value='" . $price . "'>
    </div>
    <div class='row d-flex justify-content-center'>
        <form method='post' class='mx-2'>
            <button type='submit' value='" . $id . "' name='id' class='btn btn-success'>Save</button>
        </form>
        <form action='index.php' method='get' class='mx-2'>
            <button type='submit' class='btn btn-danger'>Cancel</button>
        </form>
    </div>
</div>
</div>
        ";

}

?>

</body>
</html>
