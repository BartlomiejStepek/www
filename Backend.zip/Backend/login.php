<?php

include('header.php');

$loginError = false;

//Jeżeli otrzymaliśmy żądanie POST od klienta
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //Pobieramy dane
    $login = $_POST['login'];
    $password = $_POST['password'];

    $loginError = false;

    //Haszujemy hasło za pomocą algorytmu md5
    $passwordHash = md5($password);
    $query = "SELECT * FROM user WHERE login='$login' AND password='$passwordHash'";
    //wykonujemy polecenie sql
    $results = mysqli_query($db, $query);
    //jeżeli użytkownik o podanym loginie oraz haszu hasła istnieje to zapisujemy login w sesji, jeżeli nie to wypisujemy błąd
    if (mysqli_num_rows($results) == 1) {
        $_SESSION['username'] = $login;
        header('location: index.php');
    } else {
        $loginError = true;
    }

}

?>

<div class="container ">

    <h1 class="text-center">Login</h1>
    <hr>

    <div class="row  m-5 justify-content-center">
        <form method="post" class="col-md-3">

            <div class="form-group">
                <label for="login">Login</label>
                <input type="text" class="form-control" id="login" name="login"
                       value="<?php if (isset($login)) echo "$login"; ?>" placeholder="Enter login">
                <?php
                if ($loginError) {
                    echo '<span style="color: red">Nieprawidłowy login lub hasło</span>';
                }
                ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password"
                       value="<?php if (isset($password)) echo "$password"; ?>" placeholder="Enter password">
            </div>

            <button type="submit" class="col btn btn-primary">Sign In</button>

        </form>
    </div>
</div>

