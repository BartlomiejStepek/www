<?php

include('header.php');

$loginError = false;
$loginErrorDescription = array();

$passwordError = false;
$passwordErrorDescription = array();

$repeatPasswordError = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $login = $_POST['login'];
    $password = $_POST['password'];
    $repeatPassword = $_POST['repeatPassword'];


    //LOGIN ERRORS
    if (!preg_match("/^.{8,20}$/", $login)) {
        $loginError = true;
        array_push($loginErrorDescription, "Login musi zawierać od 8 do 20 znaków!");
    }

    if (!preg_match("/.*[A-Z]/", $login)) {
        $loginError = true;
        array_push($loginErrorDescription, "Login musi zawierać co najmniej jedną dużą literę!");
    }

    if (!preg_match("/.*[a-z]/", $login)) {
        $loginError = true;
        array_push($loginErrorDescription, "Login musi zawierać co najmniej jedną małą literę!");
    }

    //PASSWORD ERRORS
    if (!preg_match("/^.{8,20}$/", $password)) {
        $passwordError = true;
        array_push($passwordErrorDescription, "Hasło musi zawierać od 8 do 20 znaków!");
    }

    if (!preg_match("/.*[A-Z]/", $password)) {
        $passwordError = true;
        array_push($passwordErrorDescription, "Hasło musi zawierać co najmniej jedną dużą literę!");
    }

    if (!preg_match("/.*[a-z]/", $password)) {
        $passwordError = true;
        array_push($passwordErrorDescription, "Hasło musi zawierać co najmniej jedną małą literę!");
    }

    if (!preg_match("/.*[0-9]/", $password)) {
        $passwordError = true;
        array_push($passwordErrorDescription, "Hasło musi zawierać co najmniej jedną cyfrę!");
    }

    if (!preg_match("/.*[!@#$%^&*-]/", $password)) {
        $passwordError = true;
        array_push($passwordErrorDescription, "Hasło musi zawierać co najmniej jeden znak specjalny (!@#$%^&*-)!");
    }


    //REPEAT PASSWORD ERROR
    if ($repeatPassword != $password) {
        $repeatPasswordError = true;
    }

    if (!$loginError && !$passwordError && !$repeatPasswordError) {

        if (isset($_POST['reg_button'])) {

            $user_check_query = "SELECT * FROM user WHERE login='$login' LIMIT 1";
            $result = mysqli_query($db, $user_check_query);
            $user = mysqli_fetch_assoc($result);

            //Jeżeli użytkownik o podanym loginie już istnieje to zwracamy błąd
            if ($user) {
                if ($user['login'] === $login) {
                    $loginError = true;
                    array_push($loginErrorDescription, "Użytkownik o podanej nazwie już istnieje");
                }
            }else{
                //Inaczej haszujemy hasło i dodajemy użytkownika do bazy danych
                $password = md5($password);
                $query = "INSERT INTO user (login, password) VALUES('$login', '$password')";
                mysqli_query($db, $query);
                $_SESSION['username'] = $login;
                header('location: index.php');
            }
        }
    }
}

?>

<div class="container ">

    <h1 class="text-center">Registration</h1>
    <hr>

    <div class="row  m-5 justify-content-center">
        <form method="post" class="col-md-3">

            <div class="form-group">
                <label for="login">Login</label>
                <input type="text" class="form-control" id="login" name="login"
                       value="<?php if (isset($login)) echo "$login"; ?>" placeholder="Enter login">
                <?php
                if ($loginError) {
                    foreach ($loginErrorDescription as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password"
                       value="<?php if (isset($password)) echo "$password"; ?>" placeholder="Enter password">
                <?php
                if ($passwordError) {
                    foreach ($passwordErrorDescription as $item => $value) {
                        echo '<span style="color: red">' . $value . '</span><br>';
                    }
                }
                ?>
            </div>

            <div class="form-group">
                <label for="repeatPassword">Repeat password</label>
                <input type="password" class="form-control" id="repeatPassword" name="repeatPassword"
                       value="<?php if (isset($repeatPassword)) echo "$repeatPassword"; ?>"
                       placeholder="Repeat password">

                <?php
                if ($repeatPasswordError) {
                    echo '<span style="color: red">Hasła nie pasują do siebie!</span><br>';
                }
                ?>

            </div>

            <button type="submit" class="col btn btn-primary" name="reg_button">Sign Up</button>

        </form>
    </div>
</div>
