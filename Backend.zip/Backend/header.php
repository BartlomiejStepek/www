<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Registration Login App</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css"/>
</head>
<body style="padding: 100px; background-color: whitesmoke">

<?php

require_once "config.php";

if(isset($_SESSION['username'])){
    echo '<a href="/RegisterLogin/Products/index.php">Products</a> | <a href="/RegisterLogin/Employees/index.php">Employees</a> | <a href="/RegisterLogin/logout.php">Logout</a>';
}else{
    echo '<a href="/RegisterLogin/registration.php">Registration</a> | <a href="/RegisterLogin/login.php">Login</a>';
}

?>

<hr>

</body>
</html>
